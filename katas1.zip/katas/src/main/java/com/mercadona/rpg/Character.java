package com.mercadona.rpg;

import lombok.Data;

@Data
public class Character {
    private int health;
    private int level;
    private boolean alive;

    public Character() {
        this.health = 1000;
        this.level = 1;
        this.alive = true;
    }

    public void getDamage(int damage){
        health = health-damage;
            if (health<0){
                health = 0;
                alive = false;
            }
    }

    public void getHeal(int heal){
        if (alive){
            if (health<1000){
                health = health+heal;
            }else if (health==1000){
                health = 1000;
            }
        }else{
            health = 0;
        }
    }

}
