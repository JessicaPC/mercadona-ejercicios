import com.mercadona.rpg.Character;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CharacterTests {

    @Test
    void whenCreatedCharacterMustHave1000Health() {
        Character character = new Character();
        assertEquals(1000, character.getHealth());
    }

    @Test
    void whenCreatedCharacterMustHaveLevel1(){
        Character character = new Character();
        assertEquals(1, character.getLevel());
    }

    @Test
    void whenCreatedCharacterMustBeAlive(){
        Character character = new Character();
        assertTrue(character.isAlive());
    }

    @Test
    void whenCharacterDoDamage(){
        //given
        Character character = new Character();
        character.setHealth(100);
        //when
        character.getDamage(10);
        //then
        assertEquals(90, character.getHealth());
    }

    @Test
    void whenCharacterDies(){
        Character character = new Character();
        character.setHealth(100);
        character.getDamage(200);
        assertFalse(character.isAlive());
    }

    @Test
    void whenCharacterDoHeal(){
        Character character = new Character();
        character.setHealth(700);
        character.getHeal(200);
        assertEquals(900, character.getHealth());
    }

    @Test
    void whenCharacterCantHeal(){
        Character character = new Character();
        character.setHealth(1000);
        character.getHeal(200);
        assertEquals(1000, character.getHealth());
    }


    @Test
    void whenDeadCharacterCantHeal(){
        Character character = new Character();
        character.setAlive(false);
        character.getHeal(200);
        assertEquals(0, character.getHealth());
    }
}
