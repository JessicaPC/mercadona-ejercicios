package org.example;

import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        boolean salir = false;
        int longitudMeseta;
        int latitudMeseta;
        String opcion="";

        // Pedir tamaño meseta
        System.out.println("Introduce tamaño de la meseta ejemplo: 5 5 = (5x5)");
            longitudMeseta = Integer.parseInt(entrada.next());
            latitudMeseta = Integer.parseInt(entrada.next());


        do{
            menu();
            System.out.println("Introduce una opcion");
                opcion = entrada.next();


                switch (opcion){
                    case "1":
                        System.out.println("Introduce la posicion: x,y,orientacion ejemplo: 1 2 N");
                            int posX = Integer.parseInt(entrada.next());
                            int posY = Integer.parseInt(entrada.next());
                            String orientacion = entrada.next();

                        System.out.println("Introduce la direccion: L,R y M ejemplo: LMLMLMLMM");
                        String direccionEntera = entrada.next();

                        for (int i = 0; i < direccionEntera.length(); i++) {
                            char direccion = direccionEntera.charAt(i);
                                switch (direccion){
                                    case 'L':
                                         switch (orientacion){
                                             case "N":
                                                 orientacion = "W";
                                                 break;

                                             case "W":
                                                 orientacion = "S";
                                                 break;

                                             case "S":
                                                 orientacion = "E";
                                                 break;

                                             case "E":
                                                 orientacion = "N";
                                                 break;
                                         }
                                        break;

                                    case 'R':
                                        switch (orientacion){
                                            case "N":
                                                orientacion = "E";
                                                break;

                                            case "W":
                                                orientacion = "N";
                                                break;

                                            case "S":
                                                orientacion = "W";
                                                break;

                                            case "E":
                                                orientacion = "S";
                                                break;
                                        }
                                        break;

                                    case 'M':
                                        switch (orientacion){
                                            case "N":
                                                posY++;
                                                break;

                                            case "W":
                                                posX--;
                                                break;

                                            case "S":
                                                posY--;
                                                break;

                                            case "E":
                                                posX++;
                                                break;
                                        }
                                        break;
                                }
                        }

                        System.out.println("posicion final -> "+posX+" "+posY+" "+orientacion);
                        break;

                    case "2":
                        salir = true;
                        break;
                }

        }while(!salir);


    }

    public static void menu(){
        System.out.println("1.Introduce un rover");
        System.out.println("2.Salir");

    }
}
