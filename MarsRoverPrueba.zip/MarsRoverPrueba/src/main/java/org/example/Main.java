package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // leer las coordenadas de la esquina superior derecha de la meseta
        int maxX = scanner.nextInt();
        int maxY = scanner.nextInt();

        while (scanner.hasNext()) {
            // leer la posición y orientación del rover
            int x = scanner.nextInt();
            int y = scanner.nextInt();
            String dir = scanner.next();

            // leer las instrucciones para el rover
            String instructions = scanner.next();

            // procesar cada instrucción del rover
            for (int i = 0; i < instructions.length(); i++) {
                char c = instructions.charAt(i);
                if (c == 'L') {
                    // girar 90 grados a la izquierda
                    if (dir.equals("N")) {
                        dir = "W";
                    } else if (dir.equals("W")) {
                        dir = "S";
                    } else if (dir.equals("S")) {
                        dir = "E";
                    } else if (dir.equals("E")) {
                        dir = "N";
                    }
                } else if (c == 'R') {
                    // girar 90 grados a la derecha
                    if (dir.equals("N")) {
                        dir = "E";
                    } else if (dir.equals("E")) {
                        dir = "S";
                    } else if (dir.equals("S")) {
                        dir = "W";
                    } else if (dir.equals("W")) {
                        dir = "N";
                    }
                } else if (c == 'M') {
                    // mover hacia adelante
                    if (dir.equals("N")) {
                        y++;
                    } else if (dir.equals("E")) {
                        x++;
                    } else if (dir.equals("S")) {
                        y--;
                    } else if (dir.equals("W")) {
                        x--;
                    }
                }
            }

            // imprimir la posición final del rover
            System.out.println(x + " " + y + " " + dir);
        }
    }
    }
